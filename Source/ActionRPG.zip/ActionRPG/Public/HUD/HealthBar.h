// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "HealthBar.generated.h"

/**
 * 
 */
UCLASS()
class ACTIONRPG_API UHealthBar : public UUserWidget
{
	GENERATED_BODY()
public:
	UPROPERTY(meta = (BindWidget))	//Deklarujemy, �e chcemy zwi�za� ten wska�nik z widgetem w edytorze
	class UProgressBar* HealthBar;	
	
};
