// Fill out your copyright notice in the Description page of Project Settings.


#include "HUD/HealthBarComponent.h"
#include "HUD/HealthBar.h"
#include "Components/ProgressBar.h"

void UHealthBarComponent::SetHealthPercent(float Percent)
{
	
	if (HealthBarWidget == nullptr)	//Je�eli wska�nik do widgetu jest nullptr
	{
		HealthBarWidget = Cast<UHealthBar>(GetUserWidgetObject());	//Pobieramy wska�nik do widgetu paska �ycia
	}

	if (HealthBarWidget && HealthBarWidget->HealthBar)	//Je�eli wska�nik do widgetu paska �ycia oraz wska�nik do paska �ycia s� poprawne
	{
		HealthBarWidget->HealthBar->SetPercent(Percent);
	}
}
